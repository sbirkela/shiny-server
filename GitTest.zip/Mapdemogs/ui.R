library(shiny)
library(leaflet)

# Define UI for application that draws a histogram
shinyUI(bootstrapPage(
  leafletOutput("mymap", height = "800")
))  
